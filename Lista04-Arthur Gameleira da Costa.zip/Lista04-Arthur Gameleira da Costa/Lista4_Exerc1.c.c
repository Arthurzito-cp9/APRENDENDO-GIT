/*
 * Nome: Arthur Gameleira da Costa
 * N�mero de Matr�cula: 605321
 * Data Atual: 25/09/2026
 * Ambiente / Ferramenta Utilizada: Dev-C++
 */

#include <stdio.h>

int main() {
    /* 
     * a) Declarando 2 vari�veis inteiras, 2 vari�veis reais e 2 vari�veis do tipo caracter;
     * b) Atribuindo valores distintos e v�lidos a cada uma destas vari�veis;
     */
    int int1 = 15;
    int int2 = 30;
    
    float real1 = 3.14f;
    float real2 = 9.81f;
    
    char char1 = 'A';
    char char2 = 'Z';

    /* 
     * c) Fazendo a troca dos valores das 2 vari�veis inteiras e mostrando os valores 
     * das mesmas antes e depois da troca;
     */
    printf("--- Trocando valores inteiros ---\n");
    printf("Antes da troca : int1 = %d, int2 = %d\n", int1, int2);
    
    // Utilizando uma vari�vel tempor�ria para realizar a troca
    int temp = int1;
    int1 = int2;
    int2 = temp;
    
    printf("Depois da troca: int1 = %d, int2 = %d\n\n", int1, int2);

    /*
     * d) Tente atribuir vari�veis de tipos distintos (umas �s outras) e 
     * observe / informe o que acontece quanto tenta compilar o c�digo do programa;
     * 
     * RESPOSTA:
     * Ao testar a atribui��o de tipos distintos (ex: int1 = real1;), o c�digo compila, 
     * mas ocorre uma convers�o impl�cita de tipo (cast). Ao atribuir um 'float' a um 'int', 
     * a parte decimal � truncada (perdida). Dependendo do n�vel de rigorosidade do 
     * compilador no Dev-C++, ele pode gerar um "Warning" (aviso) informando sobre a 
     * poss�vel perda de dados durante essa convers�o. Atribuir um 'char' a um 'int' 
     * armazena o valor num�rico correspondente na tabela ASCII.
     */

    /*
     * e) Descreva o que acontece quando se tenta fazer uma opera��o 
     * inv�lida (como uma divis�o por Zero /0) em um programa C.
     * 
     * RESPOSTA:
     * Ao tentar compilar uma divis�o expl�cita por zero com inteiros (ex: int x = 10 / 0;), 
     * o compilador exibe um Warning ("division by zero"). No entanto, o problema maior 
     * ocorre em tempo de execu��o: o programa sofre um travamento (crash) e � encerrado 
     * abruptamente pelo sistema operacional, geralmente lan�ando um erro de exce��o de 
     * ponto flutuante (Floating point exception).
     */

    return 0;
}
